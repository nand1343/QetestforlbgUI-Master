module.exports = class HomePage {
  open (path) {
    browser.url(path)
  }
}