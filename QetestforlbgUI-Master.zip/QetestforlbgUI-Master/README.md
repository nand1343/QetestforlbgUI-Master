# Manu-WiproTest
Resources - 
Cucumberjs
WebdriverIO

Setup -

Install webdriverio:
npm install webdriverio --save-dev

Install cucumber:
npm install wdio-cucumber-framework --save-dev

Install chai:
npm install chai

Install selenium:
npm install selenium-standalone -g

Start selenium:
node node_modules/selenium-standalone/bin/selenium-standalone start

Run:
node node_modules/webdriverio/bin/wdio wdio.conf.js
